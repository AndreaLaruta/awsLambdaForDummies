# Mi Primera Lambda — "Motiv-AWS" ⚡💜

Proyecto pequeño para la charla **Hands-on with AWS Lambda** de Geraldinne Laruta.

Es una función AWS Lambda que devuelve una página web bonita con un mensaje
motivacional + un dato curioso sobre Lambda. **No usa librerías externas**, así
que se puede pegar directamente en la consola de AWS. Cabe en la **capa gratuita**.

## Archivos

| Archivo | Para qué sirve |
|---|---|
| `lambda_function.py` | El código de la función (lo que subes a AWS). |
| `test_local.py` | Prueba la función en tu compu antes de subirla. |
| `event_ejemplo.json` | Un evento de ejemplo (lo que AWS le enviaría). |
| `salida.html` | Se genera al probar localmente; ábrelo en el navegador. |

## Probar en tu computadora (opcional, antes de subir)

Necesitas Python 3 instalado. En la terminal, dentro de esta carpeta:

```bash
python test_local.py
```

Luego abre el archivo `salida.html` en tu navegador. Deberías ver la tarjeta morada.

## Subir a AWS

Sigue la guía **`Guia-Paso-a-Paso.md`** (está en la carpeta principal).
Resumen: creas una función Lambda en la consola, pegas `lambda_function.py`,
activas una **Function URL** y listo: tienes una mini-web sin servidores. 🎉
